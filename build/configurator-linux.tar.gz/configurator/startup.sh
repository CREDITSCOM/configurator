#!/bin/sh
appname="configurator"
dirname="lib"

if [ "${dirname%$tmp}" != "/" ]; then
dirname=$PWD/$dirname
fi
LD_LIBRARY_PATH=$dirname ./$appname "$@"
